<?php 
    $connection = mysqli_connect('localhost', 'root', '','donatetheblood');
?>

<!-- or die("hell no".mysqli_connect_error()) -->